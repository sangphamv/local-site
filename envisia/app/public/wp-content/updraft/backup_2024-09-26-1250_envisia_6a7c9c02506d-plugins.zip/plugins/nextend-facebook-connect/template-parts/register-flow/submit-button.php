<br class="clear"/>
<p class="submit"><input type="submit" name="wp-submit" id="wp-submit"
                         class="button button-primary button-large" value="<?php echo esc_attr_x('Register', 'Register form submit button label', 'nextend-facebook-connect'); ?>"/>
</p>