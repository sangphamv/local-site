# imageLightbox.js
A JavaScript plugin for touch-friendly image lightbox.

## Usage and Demo
Read [how to use it](https://osvaldas.info/image-lightbox-responsive-touch-friendly).
Check the [demo](https://osvaldas.info/examples/image-lightbox-responsive-touch-friendly).